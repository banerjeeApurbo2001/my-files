package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Divide operation.
 */
public class Divide {
    private int mArgumentOne = 0;
    private int mArgumentTwo = 0;

    public Divide(int argumentOne, int argumentTwo) {
        mArgumentOne = argumentOne;
        mArgumentTwo = argumentTwo;
    }

    public String toString() {
        try {

            return String.valueOf(mArgumentOne / mArgumentTwo) + " R:" + String.valueOf(mArgumentOne % mArgumentTwo);
        }
        catch (Exception e) {
            return "You cannot divide value by 0";
            //will throw error
        }
    }
}